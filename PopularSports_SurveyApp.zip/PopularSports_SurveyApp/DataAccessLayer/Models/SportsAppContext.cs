﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using DataAccessLayer.Models;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace DataAccessLayer.Models
{
    public partial class SportsAppContext : DbContext
    {
        public SportsAppContext()
        {
        }

        public SportsAppContext(DbContextOptions<SportsAppContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Sport> Sport { get; set; }
        public virtual DbSet<SurveyData> SurveyData { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=SportsApp;Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Sport>(entity =>
            {
                entity.Property(e => e.SportName)
                    .HasMaxLength(20)
                    .IsFixedLength();
            });

            modelBuilder.Entity<SurveyData>(entity =>
            {
                entity.HasKey(e => e.SurveyId)
                    .HasName("PK__tmp_ms_x__A5481F7D57D55449");

                entity.Property(e => e.SportName)
                    .HasMaxLength(20)
                    .IsFixedLength();
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

        public DbSet<DataAccessLayer.Models.Output> Output { get; set; }
    }
}
