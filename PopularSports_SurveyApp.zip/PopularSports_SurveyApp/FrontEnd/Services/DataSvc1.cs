﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FrontEnd.Services
{
    public class DataSvc1 : IDataSvc
    {
        string url = "http://localhost:2263/api";

        HttpClient webClient = new HttpClient();
        public DataSvc1()
        {
            webClient.BaseAddress = new Uri(url);
        }
        public HttpClient getSvcRef()
        {
            return webClient;
        }
    }
}
