﻿using FrontEnd.Models;
using FrontEnd.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FrontEnd.Controllers
{
    public class SurveyController : Controller
    {
        private IDataSvc svcRef;

        public SurveyController(IDataSvc dataSvc)

        {

            svcRef = dataSvc;

        }


        [Authorize(Roles = "Users")]
        [Route("/Survey/RateSport")]
        public IActionResult RatingSport()
        {
            SportSurvey ss = new SportSurvey();
            ss.Sports = PopulateSport();
            return View(ss);
        }

        // POST: Survey/Create
        [HttpPost]
        [Route("/Survey/RateSport")]
        public IActionResult RatingSport(SportSurvey surveyData)
        {
            SurveyData sd = new SurveyData();
            surveyData.Sports = PopulateSport();
            var selectedItem = surveyData.Sports.Find(p => p.Value == surveyData.SurveyId.ToString());
            if (selectedItem != null)
            {
                selectedItem.Selected = true;
                sd.SportName = selectedItem.Text;
                sd.Rating = surveyData.Rating;
                //sd.SurveyId = (int)surveyData.SurveyId;

            }

            string data = JsonConvert.SerializeObject(sd);
            StringContent content = new StringContent(data, System.Text.Encoding.UTF8, "application/json");
            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.PostAsync(webClient.BaseAddress + "/SurveyDatas", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("RateSport");
            }
            return View();
        }
        private List<SelectListItem> PopulateSport()
        {
            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.GetAsync(webClient.BaseAddress + "/Sports").Result;

            List<Sport> sList = new List<Sport>();

            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                sList = JsonConvert.DeserializeObject<List<Sport>>(data);
            }

            List<SelectListItem> ls = new List<SelectListItem>();
            foreach (var item in sList)
            {
                ls.Add(new SelectListItem { Text = item.SportName, Value = item.SportId.ToString() });
            }
            return ls;
        }


        // GET: Survey/GetSurvey
        [Authorize(Policy ="AdminPolicy")]
        //[Route("/Survey/SurveyReport")]
        public IActionResult GetSurvey()
        {
            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.GetAsync(webClient.BaseAddress + "/SurveyDatas").Result;

            List<SurveyData> sList = new List<SurveyData>();


            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                sList = JsonConvert.DeserializeObject<List<SurveyData>>(data);
            }
            return View(sList);
        }

        [Route("/PopularSport")]
        //[Authorize(Roles ="Admin,Users")]
        public IActionResult TopRating()
        {
            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.GetAsync(webClient.BaseAddress + "/Outputs").Result;

            List<Output> sList = new List<Output>();


            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                sList = JsonConvert.DeserializeObject<List<Output>>(data);
            }
            return View(sList);
        }
    }
}
