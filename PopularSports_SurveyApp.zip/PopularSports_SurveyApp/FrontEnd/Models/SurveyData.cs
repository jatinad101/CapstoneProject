﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace FrontEnd.Models
{
    public class SurveyData
    {
        [Key]
        public int SurveyId { get; set; }
       
        public string SportName { get; set; }
        public int? Rating { get; set; }
    }
}
