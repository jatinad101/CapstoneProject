﻿using FrontEnd.Models;
using FrontEnd.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace FrontEnd.Controllers
{
    public class SportsController : Controller
    {
        private IDataSvc svcRef;

        public SportsController(IDataSvc dataSvc)
        {
            svcRef = dataSvc;
        }

        // GET: 
        public IActionResult GetSport()
        {
            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.GetAsync(webClient.BaseAddress + "/Sports").Result;

            List<Sport> sList = new List<Sport>();

            
            if (response.IsSuccessStatusCode)
            {
                string data = response.Content.ReadAsStringAsync().Result;
                sList = JsonConvert.DeserializeObject<List<Sport>>(data);
            }
            return View(sList);
        }



        // GET: Sports/Create
        [Authorize(Policy ="AdminPolicy")]
        [Route("/Sports/CreateSport")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Sports/Create
        [HttpPost]
        public IActionResult Create(Sport sports)
        {
            //var sobject = new Sport {
            //    SportId=6,
            //    SportName="Tennis"
            //};
            string data = JsonConvert.SerializeObject(sports);
            //string data = JsonConvert.SerializeObject(sobject);
            StringContent content = new StringContent(data, System.Text.Encoding.UTF8, "application/json");

            var webClient = svcRef.getSvcRef();
            HttpResponseMessage response = webClient.PostAsync(webClient.BaseAddress + "/Sports", content).Result;
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("GetSport");
            }
            return View();
        }
    }
}
