﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FrontEnd.Models
{
    public class SportSurvey
    {
        public List<SelectListItem> Sports { get; set; }

        public int? SurveyId { get; set; }

        public int? Rating { get; set; }
    }
}
