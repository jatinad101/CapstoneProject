﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccessLayer.Models;

namespace DataAccessLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OutputsController : ControllerBase
    {
        private readonly SportsAppContext _context;

        public OutputsController(SportsAppContext context)
        {
            _context = context;
        }

        // GET: api/Outputs
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Output>>> GetOutput()
        {
            string StoredProc = "exec popularsport";

            return await _context.Output.FromSqlRaw(StoredProc).ToListAsync();
        }
        /*
        // GET: api/Outputs/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Output>> GetOutput(string id)
        {
            var output = await _context.Output.FindAsync(id);

            if (output == null)
            {
                return NotFound();
            }

            return output;
        }

        // PUT: api/Outputs/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutOutput(string id, Output output)
        {
            if (id != output.SportName)
            {
                return BadRequest();
            }

            _context.Entry(output).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!OutputExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Outputs
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<Output>> PostOutput(Output output)
        {
            _context.Output.Add(output);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (OutputExists(output.SportName))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetOutput", new { id = output.SportName }, output);
        }

        // DELETE: api/Outputs/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<Output>> DeleteOutput(string id)
        {
            var output = await _context.Output.FindAsync(id);
            if (output == null)
            {
                return NotFound();
            }

            _context.Output.Remove(output);
            await _context.SaveChangesAsync();

            return output;
        }
         
        private bool OutputExists(string id)
        {
            return _context.Output.Any(e => e.SportName == id);
        }
       */
    }
}
