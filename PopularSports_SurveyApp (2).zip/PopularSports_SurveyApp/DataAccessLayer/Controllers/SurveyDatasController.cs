﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DataAccessLayer.Models;

namespace DataAccessLayer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SurveyDatasController : ControllerBase
    {
        private readonly SportsAppContext _context;

        public SurveyDatasController(SportsAppContext context)
        {
            _context = context;
        }

        // GET: api/SurveyDatas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<SurveyData>>> GetSurveyData()
        {
            return await _context.SurveyData.ToListAsync();
        }

        // GET: api/SurveyDatas/5
        [HttpGet("{id}")]
        public async Task<ActionResult<SurveyData>> GetSurveyData(int id)
        {
            var surveyData = await _context.SurveyData.FindAsync(id);

            if (surveyData == null)
            {
                return NotFound();
            }

            return surveyData;
        }

        // PUT: api/SurveyDatas/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSurveyData(int id, SurveyData surveyData)
        {
            if (id != surveyData.SurveyId)
            {
                return BadRequest();
            }

            _context.Entry(surveyData).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SurveyDataExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/SurveyDatas
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<SurveyData>> PostSurveyData(SurveyData surveyData)
        {
            _context.SurveyData.Add(surveyData);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSurveyData", new { id = surveyData.SurveyId }, surveyData);
        }

        // DELETE: api/SurveyDatas/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<SurveyData>> DeleteSurveyData(int id)
        {
            var surveyData = await _context.SurveyData.FindAsync(id);
            if (surveyData == null)
            {
                return NotFound();
            }

            _context.SurveyData.Remove(surveyData);
            await _context.SaveChangesAsync();

            return surveyData;
        }

        private bool SurveyDataExists(int id)
        {
            return _context.SurveyData.Any(e => e.SurveyId == id);
        }
    }
}
